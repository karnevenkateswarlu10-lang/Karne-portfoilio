KARNE VENKATESWARLU — PREMIUM CREATIVE PORTFOLIO

HOW TO OPEN:
1. Right-click the ZIP and choose "Extract All".
2. Open the extracted folder.
3. Double-click index.html. It opens in your default web browser.
4. Keep index.html, style.css, script.js, resume.pdf, and the assets folder together.
   Do not open index.html from inside the ZIP.

FILES:
- index.html: all portfolio sections and content
- style.css: premium creative theme and responsive layout
- script.js: mobile navigation and current year
- resume.pdf: the résumé you supplied; used by the Download résumé button
- assets/profile.jpg: your uploaded photo

NOTES:
- The portfolio content was based on your uploaded résumé.
- Your photo is shown in grayscale to match the creative design.
- Google Fonts require an internet connection; the website still works offline with fallback fonts.
- Update the LinkedIn and GitHub URLs in index.html with your exact profile links if you want them to open your own profiles.
- Check all project descriptions before publishing.
